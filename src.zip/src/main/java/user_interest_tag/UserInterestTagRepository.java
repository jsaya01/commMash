package user_interest_tag;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserInterestTagRepository extends JpaRepository<UserInterestTag, Long>{
}
